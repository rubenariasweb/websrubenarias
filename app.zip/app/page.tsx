// app/page.tsx
"use client";

import { motion } from "framer-motion";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

export default function Home() {
  return (
    <main className="relative min-h-screen bg-[#0a1f1f] text-white font-inter overflow-hidden">
      {/* Fondo con imagen + zoom animado */}
      <motion.div
        initial={{ scale: 1 }}
        animate={{ scale: 1.1 }}
        transition={{ duration: 15, repeat: Infinity, repeatType: "reverse" }}
        className="absolute inset-0 -z-20"
        style={{
          backgroundImage: "url('/background.png')", // tu imagen exportada
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.25, // baja opacidad para no competir con el 3D
        }}
      />

      {/* Fondo 3D con portátil */}
      <div className="absolute inset-0 -z-10">
        <Canvas camera={{ position: [0, 0, 5] }}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[5, 5, 5]} />
          <mesh rotation={[0.3, 0.8, 0]}>
            <boxGeometry args={[2, 1.2, 0.1]} />
            <meshStandardMaterial color="#00f5d4" />
          </mesh>
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1} />
        </Canvas>
      </div>

      {/* Header */}
      <header className="flex items-center justify-between px-8 py-4 bg-black/50 backdrop-blur-md border-b border-gray-800 sticky top-0 z-50">
        <div className="font-bold text-xl text-primary">MiPortfolio</div>
        <nav className="flex gap-6 text-gray-300">
          <a href="#about" className="hover:text-white transition">Sobre mí</a>
          <a href="#services" className="hover:text-white transition">Servicios</a>
          <a href="#portfolio" className="hover:text-white transition">Portafolio</a>
          <a href="#contact" className="hover:text-white transition">Contacto</a>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative flex flex-col items-center justify-center text-center px-6 py-40 min-h-screen">
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-6"
        >
          Ruben Arias
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-lg md:text-xl max-w-2xl text-gray-200"
        >
          Aquí puedes escribir un par de líneas sobre ti y lo que ofreces como desarrollador web.
        </motion.p>
      </section>

      {/* Sección sobre mí */}
      <section className="relative px-6 py-20 max-w-5xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-3xl font-bold mb-4">Un poco sobre mí</h2>
          <p className="text-gray-300 mb-4">
            Tengo más de [X] años de experiencia desarrollando soluciones web modernas y escalables.
            Me especializo en ayudar a pymes y emprendedores a dar el salto digital con una presencia online fuerte.
          </p>
          <a href="#portfolio" className="text-primary hover:underline">
            Ver mis proyectos →
          </a>
        </div>
        <div className="bg-[#222]/70 p-6 rounded-xl shadow-md backdrop-blur-sm">
          <img
            src="/images/demo.png"
            alt="Ejemplo"
            className="rounded-lg"
          />
        </div>
      </section>
    </main>
  );
}
